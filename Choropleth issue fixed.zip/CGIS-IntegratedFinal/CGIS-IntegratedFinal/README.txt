A Pen created at CodePen.io. You can find this one at http://codepen.io/atakan/pen/gqbIz.

 Got long forms on your website ? Break them up into smaller logical sections and convert it into a multi-step form with a cool progress bar. Could work for lengthy processes like registration, checkout, profile fillups, 2-factor authentication logins, etc.