console.log("In concrete map js builder");
function ConcreteMapBuilder() {
	//Call parent constructor explicitly
	MapBuilder.call(this);
	console.log("ConcreteMapBuilder constructor");	
	//Now we ensure that the methods from the parent class are available to the child class.
	//Should maybe be outside constructor
	ConcreteMapBuilder.prototype = Object.create(MapBuilder.prototype);
	ConcreteMapBuilder.prototype.constructor = ConcreteMapBuilder;
}

//Implements parent's pure virtual functions
ConcreteMapBuilder.prototype.buildMapHeading = function() {
	console.log("buildMapHeading");	
};

ConcreteMapBuilder.prototype.buildMapLegend = function(colorClasses, classNames, mapType) {
	console.log("buildMapLegend");


            for(var i = 0; i < colorClasses.length; i++)//This is for the legend.
            {
            	console.log("Added the element :" + classNames[i]);
                document.getElementById("mapKey").innerHTML += "<svg height=\"50\" width=\"200\">" +
                    "<circle cx=\"25\" cy=\"25\" r=\"20\" stroke=\"black\" stroke-width=\"3\" fill=\"hsla(" + colorClasses[i] + ", 100%, 47%, 0.6)\" />"
                    + "<text x=\"60\" y=\"30\" fill=\"black\" font-size=\"14\">" + classNames[i] + "</text> </svg><hr>";
                   
            }
            
        

	// //double check mapType number
	// if ((mapType != 1) && (colorClasses == null || classNames == null)) {

	// 	console.log("colorClasses or classNames is NULL");

	// } else if (mapType == 0) {
			

	// } else if (mapType == 1) {

	// 	console.log("buildMapLegend mapType = 1");
	// }
};

ConcreteMapBuilder.prototype.buildMapScale = function() {
	console.log("buildMapScale");	
};

ConcreteMapBuilder.prototype.buildMapNorthArrow = function() {
	console.log("buildMapNorthArrow");
};

ConcreteMapBuilder.prototype.buildMapMetaData = function() {
	console.log("buildMapMetaData");
};