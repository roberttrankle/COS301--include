var arr = [{"robertAdmin":"geoserver123"}, {"cianAdmin":"pineapples12"}];
function validateAdmin(){
	var aUsrme = document.forms["loginForm"]["adminUsername"].value;
	var aPass = document.forms["loginForm"]["adminPassword"].value;
	var count = 0;

	for(var i = 0; i < arr.length; i++)
	{
		for(key in arr[i])
		{
			if(key == aUsrme)
			{
				count++;
				var val = arr[i][key];
				if(val == aPass)
				{
					alert("Login Succeful");
					document.getElementById("login").style.display = "none";
				}
				else
				{
					alert("Login Failure : incorrect password");
				}
			}
		}
	}
	if(count == 0)
	{
		alert("Login Failure : incorrect username");
	}
}

document.getElementById("password")
    .addEventListener("keyup", function(event) {
    event.preventDefault();
    if (event.keyCode == 13) {
        document.getElementById("loginButton").click();
    }
});