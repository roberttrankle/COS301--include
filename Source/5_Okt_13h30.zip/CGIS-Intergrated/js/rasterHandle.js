var rasterHandler = function(map, layer1) {
	this.Xn = 0.950470;
	this.Yn = 1;
	this.Zn = 1.088830;
	this.t0 = 4 / 29;
	this.t1 = 6 / 29;
	this.t2 = 3 * this.t1 * this.t1;
	this.t3 = this.t1 * this.t1 * this.t1;
	this.twoPi = 2 * Math.PI;
	console.log(map.getLayers()[1]);
	raster = new ol.source.Raster({
        sources: [new ol.source.OSM(),layer1],
        operation: function(pixels, data) {
          var hcl =this.rgb2hcl(pixels[0]);

          var h = hcl[0] + Math.PI * data.hue / 180;
          if (h < 0) {
            h += this.twoPi;
          } else if (h > this.twoPi) {
            h -= this.twoPi;
          }
          hcl[0] = h;

          hcl[1] *= (data.chroma / 100);
          hcl[2] *= (data.lightness / 100);

          return this.hcl2rgb(hcl);
        },
        lib: {
          rgb2hcl: this.rgb2hcl,
          hcl2rgb: this.hcl2rgb,
          rgb2xyz: this.rgb2xyz,
          lab2xyz: this.lab2xyz,
          xyz2lab: this.xyz2lab,
          xyz2rgb: this.xyz2rgb,
          Xn: this.Xn,
          Yn: this.Yn,
          Zn: this.Zn,
          t0: this.t0,
          t1: this.t1,
          t2: this.t2,
          t3: this.t3,
          twoPi: this.twoPi
        }
      });
	console.log(raster);
      controls = {};

      raster.on('beforeoperations', function(event) {
        var data = event.data;
        for (var id in controls) {
          data[id] = Number(controls[id].value);
        }
      });
      console.log(raster);
      var controlIds = ['hue', 'chroma', 'lightness'];
      controlIds.forEach(function(id) {
        var control = document.getElementById(id);
        var output = document.getElementById(id + 'Out');
        control.addEventListener('input', function() {
          output.innerText = control.value;
          console.log(raster);
          raster.changed();
        });
        output.innerText = control.value;
        controls[id] = control;
      });
      var lt = new ol.layer.Image({
            source: raster
          });
      map.addLayer(lt);
      console.log("RASTER LAYER ADDED");
      console.log("LEAVING RHZ:");
};

rasterHandler.prototype = Object.create(rasterHandler.prototype);
rasterHandler.prototype.constructor = rasterHandler;

rasterHandler.prototype.rgb2hcl = function(pixel) {
    var red = this.rgb2xyz(pixel[0]);
    var green = this.rgb2xyz(pixel[1]);
    var blue = this.rgb2xyz(pixel[2]);

    var x = this.xyz2lab(
        (0.4124564 * red + 0.3575761 * green + 0.1804375 * blue) / this.Xn);
    var y = this.xyz2lab(
        (0.2126729 * red + 0.7151522 * green + 0.0721750 * blue) / this.Yn);
    var z = this.xyz2lab(
        (0.0193339 * red + 0.1191920 * green + 0.9503041 * blue) / this.Zn);

    var l = 116 * y - 16;
    var a = 500 * (x - y);
    var b = 200 * (y - z);

    var c = Math.sqrt(a * a + b * b);
    var h = Math.atan2(b, a);
    if (h < 0) {
      h += this.twoPi;
    }

    pixel[0] = h;
    pixel[1] = c;
    pixel[2] = l;

    return pixel;
}

rasterHandler.prototype.hcl2rgb = function(pixel){
        var h = pixel[0];
        var c = pixel[1];
        var l = pixel[2];

        var a = Math.cos(h) * c;
        var b = Math.sin(h) * c;

        var y = (l + 16) / 116;
        var x = isNaN(a) ? y : y + a / 500;
        var z = isNaN(b) ? y : y - b / 200;

        y = Yn * this.lab2xyz(y);
        x = Xn * this.lab2xyz(x);
        z = Zn * this.lab2xyz(z);

        pixel[0] = this.xyz2rgb(3.2404542 * x - 1.5371385 * y - 0.4985314 * z);
        pixel[1] = this.xyz2rgb(-0.9692660 * x + 1.8760108 * y + 0.0415560 * z);
        pixel[2] = this.xyz2rgb(0.0556434 * x - 0.2040259 * y + 1.0572252 * z);

        return pixel;
      };

rasterHandler.prototype.xyz2lab = function(t){
	return t > this.t3 ? Math.pow(t, 1 / 3) : t / this.t2 + this.t0;
}

rasterHandler.prototype.lab2xyz = function(t){
	return t > this.t1 ? t * t * t : this.t2 * (t - this.t0);
}

rasterHandler.prototype.rgb2xyz = function(x){
	return (x /= 255) <= 0.04045 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4);
}

rasterHandler.prototype.xyz2rgb= function(x) {
	return 255 * (x <= 0.0031308 ?
  	12.92 * x : 1.055 * Math.pow(x, 1 / 2.4) - 0.055);
}