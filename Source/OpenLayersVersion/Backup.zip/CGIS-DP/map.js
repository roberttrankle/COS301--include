// function loadTMap(displayValue){
//     map.removeLayer(symbolLayer);
//     map.removeLayer(wardsVectorLayer);
//     map.removeLayer(featureLayer);
//     loadMap(displayValue);
//     wardPrevLoaded = 1;
// }
var mapDesign;
function loadMap(val){ 
  if(mapDesign == undefined)
  {
    mapDesign = new MapDesign();
    console.log("DEFINE MAPDESIGN");
  }
  mapDesign.removeLayers();
  mapDesign.isSourceReady(val);
}

function loadDatasetAttributes(url, callback){
    var feat;
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.onreadystatechange = function () {
        if (xmlHttp.readyState == 4 && xmlHttp.status == 200){
            callback(this);
        }
    };
    xmlHttp.open("GET", url,true);
    xmlHttp.send(null);
}

//Change in hmtl
function changeDatasetAttributes(val){
    if(val.value == 1)
    {
        loadDatasetAttributes('http://localhost:8080/geoserver/wfs?service=WFS&' +
          'version=1.1.0&request=DescribeFeatureType&typename=Given:copc_households&' +
          'outputFormat=application/json&srsname=EPSG:4326&maxFeatures=1', changeAttributes);
    }
}

function changeAttributes(feat){
    var obj = feat.responseText.substring(feat.responseText.indexOf("[{\"name\""),feat.responseText.lastIndexOf("}]}"));
    var arr = JSON.parse(obj);
    for(var i = 1; i < arr.length; i++)
    {
        for(key in arr[i])
        {
            if(key == 'name')
            {
                var val = arr[i][key];
                console.log(val);
                document.getElementById("tablebody").innerHTML += "<tr><td><input type=\"checkbox\" value=\"" + val + "\"" + "></td><td>"
                + val + 
                "</td></tr>";
            }
        }
    }
}

// Receive the getCapabilities request
function receiveDataSets(url, callback){
    var feat;
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.onreadystatechange = function () {
        if (xmlHttp.readyState == 4 && xmlHttp.status == 200){
            callback(this);
        }
    };
    xmlHttp.open("GET", url,true);
    xmlHttp.send(null);
}

// Request capabilities which contain the names of datasets
function requestCapabilities(){
    receiveDataSets('http://localhost:8080/geoserver/wfs?service=WFS&version=1.1.0&request=GetCapabilities&outputFormat=application/json',
        listDataSets);
}


// var vectorSource;
//This uses jQuery which is to be added in the html :  
function listDataSets(response){
    var obj = response.responseText;
    var featureDatabases = []
    var xmlDoc = $.parseXML(obj);
    var $xml = $(xmlDoc);
    var $featureDB = $xml.find("FeatureType");
    $featureDB.each(function(){
        featureDatabases.push($(this).find("Name").text());
    });
    console.log(featureDatabases);

    if (mapDesign == undefined){
        console.log("Creating MD temp");
        mapDesign = new MapDesign();
        console.log("Listing unique values:");
        mapDesign.listUniqueAttributeValues();
        mapDesign = undefined;
    } else {
        console.log("Listing unique values:");
        mapDesign.listUniqueAttributeValues();
    }

    return featureDatabases;
}

// function getUniqueDiscreteValues(attributeTitle) {
//     var tempVectorLayerClasses = [];
//     this.vectorSource.forEachFeature(function(feature) {
//        if (tempVectorLayerClasses.indexOf(feature.get(attributeTitle)) == -1) {
//             tempVectorLayerClasses.push(feature.get(attributeTitle));
//         }
//     });
//     if(tempVectorLayerClasses.length <= 0) {
//         console.log("No attribute values found");
//     }
//     this.vectorLayerClasses = tempVectorLayerClasses;
//     console.log(tempVectorLayerClasses);
//     return tempVectorLayerClasses;
// }

// function listUniqueAttributeValues() {
//     this.createVectorSource(this.vectorSourceTypeName);
//     this.createFeatureLayer();
//     this.loadSources();
//     if (this.vectorSource.getState() != 'ready') {
//         this.vectorSource.on('change', function(evt) {
//             var source = evt.target;
//             if (source.getState() == 'ready') {
//                 this.recursiveWaitAndList();
//             }
//         });
//     } else {
//         this.recursiveWaitAndList();
//     }
// }

// recursiveWaitAndList = function() {
//     if (this.vectorSource == undefined || this.vectorSource.getFeatures().length <= 0) {
//         console.log("Waiting for VS: VSc=" + this.vectorSource.getFeatures().length);
//         var that = this;
//         setTimeout(function() { 
//             that.recursiveWaitAndList();
//         }, 500);
//         return;
//     } else {
//         console.log("Features ready:");
//         console.log(this.vectorSource.getFeatures());
//         this.uniqueAttributeValues = this.getUniqueDiscreteValues(this.featureToDisplay);
//         console.log(this.uniqueAttributeValues);
//         // this.vectorSource.clear();
//         // this.vectorSource = undefined;
//     }
// }



// /* Citations
//   A: https://gis.stackexchange.com/questions/167112/how-to-create-a-circle-in-openlayers-3
//   B: https://stackoverflow.com/questions/25924762/is-it-possible-to-identify-all-the-feature-layer-inside-of-other-layer
