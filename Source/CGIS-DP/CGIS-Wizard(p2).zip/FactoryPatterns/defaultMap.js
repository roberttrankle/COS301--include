//Concrete Creator
function defaultMapCreator() {
};

defaultMapCreator.prototype = Object.create(MapCreator.prototype);
defaultMapCreator.prototype.constructor = defaultMapCreator;

defaultMapCreator.prototype.createMap = function(map) {
    console.log("DisplayDEFAULTMAP");
    this.tileLayer = new ol.layer.Tile({ source: new ol.source.OSM() });
    map.addLayer(this.tileLayer);
};

function defaultMapDesign(map) {
	
};

defaultMapDesign.prototype = Object.create(MapDesign.prototype);
defaultMapDesign.prototype.constructor = defaultMapDesign;