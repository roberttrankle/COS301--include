function Quantile() {
    //Call parent constructor explicitly
    Classification.call(this);
    console.log("Quantile constructor");
    //Now we ensure that the methods from the parent class are available to the child class.
    //Should maybe be outside constructor


}

Quantile.prototype = Object.create(Classification.prototype);
Quantile.prototype.constructor = Quantile;

function isInt(n) {
    return Number(n) === n && n % 1 === 0;
}

function isFloat(n) {
    return Number(n) === n && n % 1 !== 0;
}
Quantile.prototype.QuantileExecute = function(vectorSource, attributeTitle, numberOfClasses) {
    // console.log(" Inside QuantileExecute");
    var tempVectorLayerClasses = [];
    var classes = []; //returned quantile index classes

    if (vectorSource) {
        var numberOfElements = 0;

        vectorSource.forEachFeature(function(feature) {
            tempVectorLayerClasses.push(feature.get(attributeTitle));
            numberOfElements++;

        });

        var boundary = numberOfElements / numberOfClasses;

        var temp = 0;
        for (var i = 0; i < numberOfClasses; i++) {
            temp += (boundary);
            classes.push(temp);
            // console.log("temp" + temp );

        }

    } else {
        console.log(" Cannot find vectorSource");
    }

    return classes;z
};

Quantile.prototype.QuantileExecuteWards = function(wardsSource, keyName, index, numberOfClasses) {
    var boundriesGeometry = wardsSource.getFeatures();
    var area = 0;
    var featureCount = 0;
    var key = "AreaPerNumOccurences" + index;
    keyName[index] = key;
    var tempVectorLayerClasses = [];
    var classes = []; //returned quantile index classes

    if (wardsSource) {
        for (var i = 0; i < boundriesGeometry.length; i++) {
            featureCount++;
            tempVectorLayerClasses.push((wardsSource.getFeatures())[i].get(keyName[index]));
           // console.log(tempVectorLayerClasses[i] + " record at index " + (i + 1));
        }

       // console.log("Array inside quantile wards classification " + tempVectorLayerClasses);
        var boundary = featureCount / numberOfClasses;

        var temp = 0;
        for (var i = 0; i < numberOfClasses; i++) {
            temp += (boundary);
            classes.push(temp);
            // console.log("temp" + temp );

        }

    } else {
        console.log(" Cannot find vectorSource");
    }
    console.log(classes + "returned by quantilewards");
    return classes;

};