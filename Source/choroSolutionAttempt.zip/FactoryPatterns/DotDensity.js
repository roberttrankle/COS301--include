//Concrete Creator
function DotDensityCreator() {
    this.vectorClasses = [];
};

DotDensityCreator.prototype = Object.create(MapCreator.prototype);
DotDensityCreator.prototype.constructor = DotDensityCreator;

DotDensityCreator.prototype.createMap = function(map, vectorSource, colorPerClass, featureToDisplay, featureLayer, selectedValue) {
    var isDiscrete = false;
    if (isDiscrete) {
        var VC = [];
        var vectorStyleFunction = function(feature, resolution) {
            var hue = 0;
            if (VC != undefined) {
                if (VC.indexOf(feature.get(featureToDisplay)) != -1) {
                    hue = colorPerClass[VC.indexOf(feature.get(featureToDisplay))];
                } else {
                    VC.push(feature.get(featureToDisplay));
                }

            } else {
                VC.push(feature.get(featureToDisplay));
            }
            /* if(tC == 0)
             {
                 for(var i = 0; i < colorPerClass.length; i++)//This is for the legend.
                 {
                     document.getElementById("mapKey").innerHTML += "<svg height=\"50\" width=\"200\">" +
                         "<circle cx=\"25\" cy=\"25\" r=\"20\" stroke=\"black\" stroke-width=\"3\" fill=\"hsla(" + colorPerClass[i] + ", 100%, 47%, 0.6)\" />"
                         + "<text x=\"60\" y=\"30\" fill=\"black\" font-size=\"14\">" + vectorLayerClasses[i] + "</text> </svg><hr>";
                 }
                 tC++;`
             }*/
            if (selectedValue == "none" || feature.get(featureToDisplay) == $("#attrValue option:selected").html()) {
                var fill = new ol.style.Fill({
                    color: 'hsla(' + 0 + ', 100%, 47%, 0.6)'
                });

                return [new ol.style.Style({
                    image: new ol.style.Circle({
                        fill: fill,
                        radius: 5
                    })
                })];
            } else {
                // return [new ol.style.Style({})];
            }
        };

        featureLayer.layer = new ol.layer.Vector({
            source: vectorSource,
            style: vectorStyleFunction
        });
        map.addLayer(featureLayer.layer);
    } else {
        featureLayer.layer = new ol.layer.Vector({
            source: vectorSource,
            style: new ol.style.Style({
                        fill: new ol.style.Fill({
                        color: 'hsla(' + 0 + ', 100%, 47%, 0.6)',
                        visible: true
                        })
            })
        });
        var pointFeatures = vectorSource.getFeatures(); // move down after testing
        var pointFeaturesLength = pointFeatures.length; // move down after testing
        var classArray = [];
        for (var i = 0; i < pointFeaturesLength; i++) {
            classArray.push(1);
        }
        if (classArray == undefined || classArray.length != pointFeatures.length) {
            console.log("classArray undefined or badly formed");
            return;
        }
        console.log(colorPerClass[0]);
        console.log(colorPerClass[1]);
        console.log(colorPerClass[2]);
        console.log(colorPerClass[3]);
        console.log(colorPerClass[4]);
        console.log(classArray);
        var classificationMethodIndex = 0;
        // ^ This is the index of the type of classication object's return value data stype
        // 0 = Array with a class index per feature
        // 1 = Lower boundaries of classes
        switch (classificationMethodIndex) {
            case 0:
                console.log("Colorising classAray in DD");
                for (var i = 0; i < pointFeaturesLength; i++) {
                    console.log(colorPerClass[classArray[i]]);
                    var pointFill = new ol.style.Fill({
                        color: 'hsla(' + colorPerClass[classArray[i]] + ', 100%, 47%, 0.6)'
                    });
                    var style = new ol.style.Style({
                        fill: pointFill,
                        visible: true,
                        stroke: new ol.style.Stroke({
                            color: 'rgba(255, 255, 255, 0.5)',
                            width: 1
                        })
                    });
                    pointFeatures[i].setStyle(style);
                    // featureLayer.drawFeature(pointFeatures[i]);
                }
                break;
            case 1:
                break;
            case 2:
                break;
        }
        featureLayer.layer = new ol.layer.Vector({
            source: vectorSource
        });
        featureLayer.layer.setZIndex(map.getLayers().getArray().length -1   )
        map.addLayer(featureLayer.layer);
        console.log(map.getLayers());
    }
};

function DotDensityDesign(map) {
    this.map = map;
};

DotDensityDesign.prototype = Object.create(MapDesign.prototype);
DotDensityDesign.prototype.constructor = DotDensityDesign;