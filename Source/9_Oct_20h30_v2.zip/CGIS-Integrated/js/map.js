var datasets;
var mapDesign;
function loadMap(mapType, pageToLoad, callback) {
    if (mapDesign == undefined) {
        mapDesign = new MapDesign();
    }
    if (pageToLoad == 2) {
        mapDesign.isSourceReady(mapType, pageToLoad, loadWizardMaps);
    } else if (pageToLoad == 3) {
        mapDesign.isSourceReady(mapType, pageToLoad, loadColorSchemes);
    } else if (pageToLoad == 4) {
        mapDesign.isSourceReady(mapType, pageToLoad, loadClassificationAndClasses);
    } else {
        mapDesign.isSourceReady(mapType, pageToLoad);
    }
}

function loadWizardMaps(mapToLoad) {
    if (mapToLoad < 5) {
        loadMap(mapToLoad, 2);
    }
    if (mapToLoad == 5) {
        mapDesign.wizardMapArray[0].setTarget("mapType_DotDensity");
        mapDesign.wizardMapArray[1].setTarget("mapType_Heatmap");
        mapDesign.wizardMapArray[2].setTarget("mapType_Choropleth");
        mapDesign.wizardMapArray[3].setTarget("mapType_PropSymbol");
    }
}

function loadColorSchemes() {
  //If heatMap is chosen no color schemes should be used
  if (sessionStorage.getItem("mapTypeSelected") != "2") {
      if (mapDesign.colorSchemeIterationCounter < 6) {
          loadMap(sessionStorage.getItem('mapTypeSelected'), 3);
      }
      if (mapDesign.colorSchemeIterationCounter == 6) {
          mapDesign.colorSchemeArray[0].setTarget('cs1');
          mapDesign.colorSchemeArray[1].setTarget('cs2');
          mapDesign.colorSchemeArray[2].setTarget('cs3');
          mapDesign.colorSchemeArray[3].setTarget('cs4');
          mapDesign.colorSchemeArray[4].setTarget('cs5');
          mapDesign.colorSchemeArray[5].setTarget('cs6');
      }
  } else if ((sessionStorage.getItem("mapTypeSelected") == "2") || (sessionStorage.getItem("mapTypeSelected") == "3")) {
        if (mapDesign.colorSchemeIterationCounter < 1) {
          loadMap(sessionStorage.getItem('mapTypeSelected'), 3);
        }
      
      else if (mapDesign.colorSchemeIterationCounter == 1){
        mapDesign.colorSchemeArray[0].setTarget('cs1');
        }
  }
}
function loadClassificationAndClasses() {
    if (sessionStorage.getItem('isDiscrete') == 'false')
    { 
        if (mapDesign.classAndClassficationIterationCounter < 9) {
            loadMap(sessionStorage.getItem('mapTypeSelected'), 4);
        }
        else if (mapDesign.classAndClassficationIterationCounter == 9) {
            mapDesign.ccMapArray[0].setTarget('cc1');
            mapDesign.ccMapArray[1].setTarget('cc2');
            mapDesign.ccMapArray[2].setTarget('cc3');
            mapDesign.ccMapArray[3].setTarget('cc4');
            mapDesign.ccMapArray[4].setTarget('cc5');
            mapDesign.ccMapArray[5].setTarget('cc6');
            mapDesign.ccMapArray[6].setTarget('cc7');
            mapDesign.ccMapArray[7].setTarget('cc8');
            mapDesign.ccMapArray[8].setTarget('cc9');
        }
    } else if (sessionStorage.getItem('isDiscrete') == 'true') {
        if (mapDesign.classAndClassficationIterationCounter < 1) {
            loadMap(sessionStorage.getItem('mapTypeSelected'), 4);
        }
        else if (mapDesign.classAndClassficationIterationCounter == 1) {
            mapDesign.ccMapArray[0].setTarget('cc1');
        }
    }
}

function loadSelectedMap() {
    mapDesign.map.setTarget('');
    mapDesign.wizardMapArray[3].map.getView().setZoom(10);
    mapDesign.wizardMapArray[3].map.setTarget("map");
}

function loadDataset(url, callback) {
    var feat;
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.onreadystatechange = function() {
        if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
            callback(this);
        }
    };
    xmlHttp.open("GET", url, true);
    xmlHttp.send(null);
}

//change when databases
function populateAtt(val) {
    for (var i = 0; i < datasets.length; i++) {
        if (val.value == i) {
            loadDataset('http://localhost:8080/geoserver/wfs?service=WFS&' +
                'version=1.1.0&request=DescribeFeatureType&typename=' + datasets[i] + '&' +
                'outputFormat=application/json&srsname=EPSG:4326&maxFeatures=1', changeAtt);
        }
    }
}


function changeAtt(feat) {
    var obj = feat.responseText.substring(feat.responseText.indexOf("[{\"name\""), feat.responseText.lastIndexOf("}]}"));
    var arr = JSON.parse(obj);

    document.getElementById("attr").innerHTML = "";
    document.getElementById("attr").innerHTML += "<option style = \"display:none\" disabled selected value = \"1\">Select an Attribute</option><br>";
    for (var i = 1; i < arr.length; i++) {
        for (key in arr[i]) {
            if (key == 'name') {
                var val = arr[i][key];
                document.getElementById("attr").innerHTML += " <option value = \"" + i+1 + "\"" + ">" + val + "</option><br>";
            }
        }
    }
}

// Receive the getCapabilities request
function receiveDataSets(url, callback) {
    var feat;
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.onreadystatechange = function() {
        if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
            callback(this);
        }
    };
    xmlHttp.open("GET", url, true);
    xmlHttp.send(null);
}

// Request capabilities which contain the names of datasets
function requestCapabilities() {
    receiveDataSets('http://localhost:8080/geoserver/wfs?service=WFS&version=1.1.0&request=GetCapabilities&outputFormat=application/json',
        changeAtt);
}

function listDataSets(response) {
    var obj = response.responseText;
    var featureDatabases = [];
    var xmlDoc = $.parseXML(obj);
    var $xml = $(xmlDoc);
    var $featureDB = $xml.find("FeatureType");
    $featureDB.each(function() {
        featureDatabases.push($(this).find("Name").text());
    });
    for (var i = 0; i < featureDatabases.length; i++) {
        document.getElementById("dataset").innerHTML += "<option value = \"" + i + "\" >" + featureDatabases[i] + "</option><br>";
        document.getElementById("boundary").innerHTML += "<option value = \"" + i + "\" >" + featureDatabases[i] + "</option><br>";
    }
    datasets = featureDatabases;
}

//still incomplete
function populateAttValues() {
    if (mapDesign == undefined) {
        mapDesign = new MapDesign();
        mapDesign.listUniqueAttributeValues();
        mapDesign = undefined;
    } else {
        mapDesign.listUniqueAttributeValues();
    }

}

$(document).ready(function() {
    receiveDataSets('http://localhost:8080/geoserver/wfs?service=WFS&version=1.1.0&request=GetCapabilities&outputFormat=application/json',
        listDataSets);
})

$(document).ready(function() {
    $("#attrValue").change(function(e) {
        e.preventDefault();
        e.stopPropagation();
        var button = $("#next1").next("button");
        if (this.value == "1") {
            button.prop("disabled", true);
        } else {
            button.prop("disabled", false)
            $('#attrNext').removeAttr('disabled');
        };
    });
})

function setAttrValue() {
    mapDesign.setAttrValue();
}

function setDataset() {
    mapDesign.setDataset();
}

function setBoundaries() {
    mapDesign.setBoundaries();
}

function setStdMethod() {
    
}
function generateBuilderAndFinalMap() {
    loadMap(sessionStorage.getItem('mapTypeSelected'), 5);
    mapDesign.loadMapLegend();
}
/* Citations
  A: https://gis.stackexchange.com/questions/167112/how-to-create-a-circle-in-openlayers-3
  B: https://stackoverflow.com/questions/25924762/is-it-possible-to-identify-all-the-feature-layer-inside-of-other-layer
*/