function StandariseMethod() {
    //Call parent constructor explicitly
    Standardise.call(this);
    console.log("StandariseMethod constructor");
    //Now we ensure that the methods from the parent class are available to the child class.
    //Should maybe be outside constructor
}

StandariseMethod.prototype = Object.create(Standardise.prototype);
StandariseMethod.prototype.constructor = StandariseMethod;


StandariseMethod.prototype.area = function(vectorSource, wardsSource, featureToDisplay, selectedValue, wardsVectorLayer, featureLayer) {
    /********************************** Area per household **************************************/

    console.log("area");

    var pointFeatures = vectorSource.getFeatures();
    var boundriesGeometry = wardsSource.getFeatures();
    var numHouseholds = 0;
    var area = 0;

    for (var i = 0; i < boundriesGeometry.length; i++) {
        for (var j = 0; j < pointFeatures.length; j++) {
            if (ol.extent.intersects(pointFeatures[j].getGeometry().getExtent(), boundriesGeometry[i].getGeometry().getExtent())) { // Cite:B
                numHouseholds++;
            }
        }
        area = boundriesGeometry[i].getGeometry().getArea();
        (wardsSource.getFeatures())[i].set('areaPerNumHousehold', (area / numHouseholds));
        numHouseholds = 0;
    }

    return wardsSource;
}

StandariseMethod.prototype.ratio = function(vectorSource, wardsSource, featureToDisplay, selectedValue, wardsVectorLayer, featureLayer) {
    console.log("ratio"); //Currently busy on it

    var pointFeatures = vectorSource.getFeatures();
    var boundriesGeometry = wardsSource.getFeatures();
    var countOfClassPerWard;
    var countPerWard = [];
    var maxClassCountOfWard = -1;
    var minClassCountOfWard = Number.POSITIVE_INFINITY;
    console.log("number of boundry features" + boundriesGeometry.length + " number of point features" + pointFeatures.length);
    for (var i = 0; i < boundriesGeometry.length; i++) {
        countOfClassPerWard = 0;
        for (var j = 0; j < pointFeatures.length; j++) {

            if (ol.extent.intersects(pointFeatures[j].getGeometry().getExtent(), boundriesGeometry[i].getGeometry().getExtent())) { // Cite:B
                if ((pointFeatures[j].get(featureToDisplay)).localeCompare(selectedValue) == 0) {
                    countOfClassPerWard = countOfClassPerWard + 1;
                }
            }
        }
        countPerWard[i] = countOfClassPerWard;
        console.log(" Number of elements per ward" + countPerWard[i]);

    }
    return countPerWard;
};

StandariseMethod.prototype.rate = function(vectorSource, wardsSource, featureToDisplay, selectedValue, wardsVectorLayer, featureLayer) {
    console.log("rate");
};

StandariseMethod.prototype.density = function(vectorSource, wardsSource, featureToDisplay, selectedValue, wardsVectorLayer, featureLayer) {
    /********************************** Households per area **************************************/

    console.log("density");
    var pointFeatures = vectorSource.getFeatures();
    var boundriesGeometry = wardsSource.getFeatures();
    var numHouseholds = 0;
    var area = 0;

    for (var i = 0; i < boundriesGeometry.length; i++) {
        for (var j = 0; j < pointFeatures.length; j++) {
            if (ol.extent.intersects(pointFeatures[j].getGeometry().getExtent(), boundriesGeometry[i].getGeometry().getExtent())) { // Cite:B
                numHouseholds++;
            }
        }

        area = boundriesGeometry[i].getGeometry().getArea();
        // householdsPerArea.push((numHouseholds/area));  //Households per meter squared
        boundriesGeometry[i].set('householdsPerArea', (numHouseholds / area));
        console.log("Count :" + numHouseholds)
        numHouseholds = 0;
    }
    return war;
};