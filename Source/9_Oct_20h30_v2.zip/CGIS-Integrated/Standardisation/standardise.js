function Standardise() {
	
	console.log("Standardise");
	if (this.constructor === Standardise) {
		throw new Error("Can't instantiate abstract class!, type must be specified");
	}
};

//Pure Virtual
Standardise.prototype.area = function( vectorSource, wardsSource, featureToDisplay, selectedValue, wardsVectorLayer, featureLayer) {};
Standardise.prototype.ratio = function( vectorSource, wardsSource, featureToDisplay, selectedValue, wardsVectorLayer, featureLayer) {};
Standardise.prototype.rate = function( vectorSource, wardsSource, featureToDisplay, selectedValue, wardsVectorLayer, featureLayer) {};
Standardise.prototype.density = function(  vectorSource, wardsSource, featureToDisplay, selectedValue, wardsVectorLayer, featureLayer) {};


