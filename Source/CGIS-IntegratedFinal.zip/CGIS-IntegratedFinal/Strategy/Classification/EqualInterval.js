function EqualInterval() {
	//Call parent constructor explicitly
	Classification.call(this);
	console.log("EqualInterval constructor");	
	//Now we ensure that the methods from the parent class are available to the child class.
	//Should maybe be outside constructor
}
	EqualInterval.prototype = Object.create(Classification.prototype);
	EqualInterval.prototype.constructor = EqualInterval;


    EqualInterval.prototype.EqualIntervalExecute = function(vectorSource, attributeTitle, numberOfClasses) {
    	console.log(" Inside EqualIntervalExecute");
        var minimum = 0;
	    var maximum = 0;
	    var interval = 0;
	   // console.log("vectorSource "+vectorSource + " attributeTitle " + attributeTitle + " numberOfClasses " + numberOfClasses);
	    var tempVectorLayerClasses = [];
	    vectorSource.forEachFeature(function(feature) {
	       if (tempVectorLayerClasses.indexOf(feature.get(attributeTitle)) == -1) {
	            tempVectorLayerClasses.push(feature.get(attributeTitle));
	           // console.log(tempVectorLayerClasses.indexOf(feature.get(attributeTitle)));
	        }
	         //console.log(tempVectorLayerClasses.indexOf(feature.get(attributeTitle)));
	    });
	    
	    minimum = tempVectorLayerClasses[0];
	    maximum = tempVectorLayerClasses[0];
	    for(var i = 0; i<tempVectorLayerClasses.length; i++ ){
	        if(tempVectorLayerClasses[i] < minimum){
	            minimum = tempVectorLayerClasses[i] ;
	        }

	        if(tempVectorLayerClasses[i] > maximum){
	            maximum = tempVectorLayerClasses[i];
	        }
	    }

	  //  console.log("minimum: "+minimum);
	  //  console.log("maximum: "+maximum);

	    interval = (maximum - minimum) / numberOfClasses;

	    tempVectorLayerClasses = [];
	    var j = 0;
	    for(var i = 0; i < numberOfClasses; i++){
	        j = j + interval;
	        tempVectorLayerClasses[i] = j;
	       // console.log("class "+i+": "+tempVectorLayerClasses[i] );
	    }
	    console.log("What is returned by interval " +tempVectorLayerClasses);
    	return tempVectorLayerClasses;
    }
	    
//EqualInterval.prototype = Object.create(Classification.prototype);
//EqualInterval.prototype.constructor = EqualInterval;