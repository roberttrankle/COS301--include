function ConcreteMapBuilder() {
    //var ConcreteMapBuilder = function(){
    //Call parent constructor explicitly


    MapBuilder.call(this);
    console.log("ConcreteMapBuilder constructor");


    //Now we ensure that the methods from the parent class are available to the child class.
    //Should maybe be outside constructor


    ConcreteMapBuilder.prototype = Object.create(MapBuilder.prototype);
    ConcreteMapBuilder.prototype.constructor = ConcreteMapBuilder;

}

//Implements parent's pure virtual functions
ConcreteMapBuilder.prototype.buildMapHeading = function() {
    // var heading = document.getElementById("mapTitle").value;
    var heading = sessionStorage.getItem('mapTitle');
    document.getElementById("heading").innerHTML = heading;
    document.getElementById("meta_title").innerHTML = heading;
    document.getElementById("meta_titleMap").innerHTML = "Title: "+heading;

    return heading;
};


ConcreteMapBuilder.prototype.buildMapLegend = function(colorPerClass, vectorLayerClasses, selectedValue) {
    document.getElementById("mapKey").innerHTML = "";
    for (var i = 0; i < colorPerClass.length; i++) //This is for the legend.
    {
        if (vectorLayerClasses[i] == selectedValue) {
            document.getElementById("mapKey").innerHTML += "<svg height=\"50\" width=\"200\">" +
                "<circle cx=\"25\" cy=\"25\" r=\"20\" stroke=\"black\" stroke-width=\"3\" fill=\"hsla(" + colorPerClass[0] + ", : " + colorPerClass[1] + "%, " + colorPerClass[2] + "%, 0.6)\" />" +
                "<text x=\"60\" y=\"30\" fill=\"black\" font-size=\"14\">" + vectorLayerClasses[i] + "</text> </svg><hr>";
        }
    }

};

// ConcreteMapBuilder.prototype.buildMapScale = function(map) {
//     console.log("buildMapScale");

//     //var scaleline = new ol.control.ScaleLine();
//     //map.addControl(scaleline);

// };

ConcreteMapBuilder.prototype.buildMapNorthArrow = function() {
    console.log("buildMapNorthArrow");

    var img = document.createElement("img");
    img.src = "BuilderPattern/north_image.jpg";
    img.style.width = 15 + "%";
    img.style.height = 15 + "%";

    var arrowDiv = document.getElementById("imageDiv");
    document.getElementById("imageDiv").innerHTML = "";
    arrowDiv.appendChild(img);

};

ConcreteMapBuilder.prototype.buildMapMetaData = function() {
    console.log("buildMapMetaData");

    var date = new Date().toDateString();

    var d = new Date(),
        h = (d.getHours()<10?'0':'') + d.getHours(),
        m = (d.getMinutes()<10?'0':'') + d.getMinutes();
    var time = h + ':' + m;

    var author = "CGIS";
    var coordinateSystem = "CGS WGS 1984";
    // var datum = "WGS 1984";
    var units = "Degree";

    var metaData = {date:date, time: time, author:"CGIS", coordinateSystem:"CGS WGS 1984", datum:"WGS 1984", units:"Degree"};
    
    document.getElementById("meta_date").innerHTML = "<span class='glyphicon glyphicon-calendar ' style='color:white'></span> Date - " +metaData.date;
    document.getElementById("meta_time").innerHTML = "<span class='glyphicon glyphicon-time ' style='color:white'></span> Time - " +metaData.time;
    document.getElementById("meta_author").innerHTML = "<span class='glyphicon glyphicon-user ' style='color:white'></span> Author - " + metaData.author;
    document.getElementById("meta_coordinate_sys").innerHTML = "<span class='glyphicon glyphicon-map-marker ' style='color:white'></span> Coordinate System - " + metaData.coordinateSystem;
    document.getElementById("meta_datum").innerHTML = "<span class='glyphicon glyphicon-globe ' style='color:white'></span> Datum - " +metaData.datum;
    document.getElementById("meta_units").innerHTML = "<span class='glyphicon glyphicon-scale ' style='color:white'></span> Units - " +metaData.units;

    document.getElementById("meta_dateMap").innerHTML = "Date - " +metaData.date;
    document.getElementById("meta_timeMap").innerHTML = "Time - " +metaData.time;
    document.getElementById("meta_authorMap").innerHTML = "Author - " + metaData.author;
    document.getElementById("meta_coordinate_sysMap").innerHTML = "Coordinate System - " + metaData.coordinateSystem;
    document.getElementById("meta_datumMap").innerHTML = "Datum - " +metaData.datum;
    document.getElementById("meta_unitsMap").innerHTML = "Units - " +metaData.units;

    return metaData;
};

